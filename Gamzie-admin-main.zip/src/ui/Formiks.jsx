import styled from "styled-components";

const Formmiks = styled.form`
  background-color: #fff;
  padding: 35px 40px;
  margin-bottom: 60px;
  border-radius: var(--border-radius-lg);
`;
export default Formmiks;
