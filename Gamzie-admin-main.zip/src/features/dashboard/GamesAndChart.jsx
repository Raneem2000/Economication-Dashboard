import React from 'react'
import GamesResults from './GamesResults'

const GamesAndChart = () => {
  return (
    <div>
        <GamesResults/>
        
    </div>
  )
}

export default GamesAndChart